<div>
    <!--[if BLOCK]><![endif]--><?php if($showUpdateModel): ?>
        <?php if (isset($component)) { $__componentOriginal49bd1c1dd878e22e0fb84faabf295a3f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal49bd1c1dd878e22e0fb84faabf295a3f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dialog-modal','data' => ['wire:model' => 'showUpdateModel','maxWidth' => '4xl']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'showUpdateModel','maxWidth' => '4xl']); ?>
         <?php $__env->slot('title', null, []); ?> 
            <?php echo e(__('Informations d\'utilisateur')); ?> 
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('content', null, []); ?> 
            <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8">



                <div class="col-span-1 md:col-span-2 ">
                    <div class="relative p-3 bg-transparent  border border-[#cecece] rounded-lg md:rounded-lg sm:rounded-sm">
                        <div class="absolute -top-4 right-3 px-3 pt-1 text-xs font-semibold bg-gray-100 rounded-t-lg"><?php echo e(__('Nom Complet')); ?></div>
                        <div class=" text-sm font-bold z-10"><?php echo e($order->first_name . " " . $order->family_name); ?></div>
                    </div>
                </div>

                <div class="col-span-1 md:col-span-2 ">
                    <div class="relative p-3 bg-transparent  border border-[#cecece] rounded-lg md:rounded-lg sm:rounded-sm">
                        <div class="absolute -top-4 right-3 px-3 pt-1 text-xs font-semibold bg-gray-100 rounded-t-lg"><?php echo e(__('Email')); ?></div>
                        <div class=" text-sm font-bold z-10"><?php echo e($order->email); ?></div>
                    </div>
                </div>

                <div class="col-span-1 md:col-span-2 ">
                    <div class="relative p-3 bg-transparent  border border-[#cecece] rounded-lg md:rounded-lg sm:rounded-sm">
                        <div class="absolute -top-4 right-3 px-3 pt-1 text-xs font-semibold bg-gray-100 rounded-t-lg"><?php echo e(__('Phone Number')); ?></div>
                        <div class=" text-sm font-bold z-10"><?php echo e($order->phone_number); ?></div>
                    </div>
                </div>



                <div class="col-span-1 md:col-span-2 ">
                    <div class="relative p-3 bg-transparent  border border-[#cecece] rounded-lg md:rounded-lg sm:rounded-sm">
                        <div class="absolute -top-4 right-3 px-3 pt-1 text-xs font-semibold bg-gray-100 rounded-t-lg"><?php echo e(__('City')); ?></div>
                        <div class=" text-sm font-bold z-10"><?php echo e($order->city); ?></div>
                    </div>
                </div>
                <div class="col-span-1 md:col-span-2 ">
                    <div class="relative p-3 bg-transparent  border border-[#cecece] rounded-lg md:rounded-lg sm:rounded-sm">
                        <div class="absolute -top-4 right-3 px-3 pt-1 text-xs font-semibold bg-gray-100 rounded-t-lg"><?php echo e(__('State / Province')); ?></div>
                        <div class=" text-sm font-bold z-10"><?php echo e($order->state_province); ?></div>
                    </div>
                </div>
                <div class="col-span-1 md:col-span-2 ">
                    <div class="relative p-3 bg-transparent  border border-[#cecece] rounded-lg md:rounded-lg sm:rounded-sm">
                        <div class="absolute -top-4 right-3 px-3 pt-1 text-xs font-semibold bg-gray-100 rounded-t-lg"><?php echo e(__('Postal code')); ?></div>
                        <div class=" text-sm font-bold z-10"><?php echo e($order->postal_code); ?></div>
                    </div>
                </div>
                <!--[if BLOCK]><![endif]--><?php if($order->products_cart): ?>
                <div class="col-span-1 md:col-span-6 ">
                    <div class="relative p-3 bg-transparent  border border-[#cecece] rounded-lg md:rounded-lg sm:rounded-sm">
                        <div class="absolute -top-4 right-3 px-3 pt-1 text-xs font-semibold bg-gray-100 rounded-t-lg"><?php echo e(__('Products')); ?></div>
                        <div class=" text-sm font-bold z-10">


                            
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = json_decode($order->products_cart, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="my-2 flex justify-between">
                                    <span>
                                        <span class="bg-gray-100  p-1 rounded">Product Name:</span>
                                        <?php echo e($item['product']); ?>  
                                    </span>
                                    <span>
                                        <span class="bg-gray-100 ml-10  p-1 rounded">Price:</span>
                                        $<?php echo e($item['price']); ?> 
                                        <span class="bg-gray-100 ml-10  p-1 rounded">Quantity:</span>
                                        <?php echo e($item['quantity']); ?> 
                                    </span>
                                </p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <div class="col-span-1 md:col-span-2 relative">

                    <select wire:model.defer="status" id="status" class="p-3 bg-transparent  border border-[#cecece] focus:border-[#cecece] rounded-lg md:rounded-lg sm:rounded-sm w-full" style="box-shadow: none; outline:none">
                        <option value="" readonly="true" hidden="true" selected><?php echo e($order->status); ?></option>
                        <option value="unpaid">unpaid</option>
                        <option value="paid">paid</option>
                    </select>
                    <div class="absolute -top-4 right-3 px-3 pt-1 text-xs font-semibold bg-gray-100 rounded-t-lg"><?php echo e(__('Status')); ?></div>
                </div>

                <div class="col-span-1 md:col-span-2 ">
                    <div class="relative p-3 bg-transparent  border border-[#cecece] rounded-lg md:rounded-lg sm:rounded-sm">
                        <div class="absolute -top-4 right-3 px-3 pt-1 text-xs font-semibold bg-gray-100 rounded-t-lg"><?php echo e(__('created_at')); ?></div>
                        <div class=" text-sm font-bold z-10"><?php echo e(date('D jS M Y',strtotime($order->created_at))); ?> </div>
                    </div>
                </div>

            </div>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('footer', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['wire:click' => 'closeUpdateModel','wire:loading.attr' => 'disabled']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'closeUpdateModel','wire:loading.attr' => 'disabled']); ?>
                <?php echo e(__('Cancel')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['type' => 'submit','wire:click' => 'edit','wire:loading.attr' => 'disabled','class' => 'ml-3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','wire:click' => 'edit','wire:loading.attr' => 'disabled','class' => 'ml-3']); ?>
                <?php echo e(__('Save')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal49bd1c1dd878e22e0fb84faabf295a3f)): ?>
<?php $attributes = $__attributesOriginal49bd1c1dd878e22e0fb84faabf295a3f; ?>
<?php unset($__attributesOriginal49bd1c1dd878e22e0fb84faabf295a3f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal49bd1c1dd878e22e0fb84faabf295a3f)): ?>
<?php $component = $__componentOriginal49bd1c1dd878e22e0fb84faabf295a3f; ?>
<?php unset($__componentOriginal49bd1c1dd878e22e0fb84faabf295a3f); ?>
<?php endif; ?>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</div>
<?php /**PATH /Users/bourezzoukmohamed/shop_/resources/views/livewire/order/order-update.blade.php ENDPATH**/ ?>